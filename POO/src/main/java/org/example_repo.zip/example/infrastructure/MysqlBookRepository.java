package org.example.infrastructure;

import org.example.domain.Book;

import java.util.ArrayList;
import java.util.List;

public class MysqlBookRepository {

    public List<Book> books;

    public MysqlBookRepository() {
        this.books = new ArrayList<>();
        System.out.println("Mysql Repository Created");
    }

    public List<Book> getBooksMysql() {
        return this.books;
    }

    public void addBookMysql(Book book) {
        this.books.add(book);
        System.out.println("Le livre " + book.getName() + " a été ajouté au repository mysql avec succès");
    }

    public void deleteBookMysql(String code) {
        for (int i = 0; i < books.size(); i++) {

            String num = books.get(i).getCode();
            System.out.println("Index" + i);
            System.out.println(code == num);
            if (code.equals(num)) {
                System.out.println("trigger");
                String name = books.get(i).getName();
                books.remove(i);

                System.out.println("Le livre " + name + " et avec le code " + num + " a été supprimer de la base de donnée mysql avec succès");

            }
        }
    }
}
