package org.example.infrastructure;

import org.example.domain.Book;

import java.util.ArrayList;
import java.util.List;

public class InMemoryBookRepository {

    public List<Book> books;

    public InMemoryBookRepository() {
        this.books = new ArrayList<>();
        System.out.println("In memory Repository Created");
    }

    public List<Book> getBooksInMemory() {
        return this.books;
    }

    public void addBookInMemory(Book book) {
        this.books.add(book);
        System.out.println("Le livre " + book.getName() + " a été ajouté au repository en RAM avec succès");
    }

    public void deleteBookInMemory(String code) {
        for (int i = 0; i < books.size(); i++) {

            String num = books.get(i).getCode();

            if (code.equals(num)) {
                String name = books.get(i).getName();
                books.remove(i);

                System.out.println("Le livre " + name + " et avec le code " + num + " a été supprimer de la RAM avec succès");

            }
        }

    }
}