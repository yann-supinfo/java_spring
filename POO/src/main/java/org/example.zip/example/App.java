package org.example;

import org.example.domain.*;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        BookFactoryManager bookFactoryManager = new BookFactoryManager();

        Book livre1 =  bookFactoryManager.createBook("autheur1", "livre1", 200, "ADVd");
      /*  AdventureBookFactory adventureBookFactory = new AdventureBookFactory();
        SfBookFactory sfBookFactory = new SfBookFactory();
        HistoryBookFactory historyBookFactory = new HistoryBookFactory();

        Book livre1 = adventureBookFactory.createAventureBook("autheur1", "livre1", 200);
        Book livre2 = adventureBookFactory.createAventureBook("autheur2", "livre2", 220);
        Book livre3 = sfBookFactory.createSfBook("autheur3", "livre3", 230);
        Book livre4 = historyBookFactory.createHistoryBook("autheur4", "livre4", 230);
        //Book livre3 = new Book("autheur3", "livre3", 240, "Litterature", "LIT-0001");
        livre1.displayInformation();
        livre2.displayInformation();
        livre3.displayInformation();
        livre4.displayInformation();*/
        livre1.displayInformation();
    }
}
